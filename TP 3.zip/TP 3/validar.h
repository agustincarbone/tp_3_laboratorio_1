#ifndef VALIDAR_H_INCLUDED
#define VALIDAR_H_INCLUDED

int esSoloLetras(char array[]);
int esNumeroChar (char num[]);
int esAlfaNumerico(char str[]);
int esTelefono(char str[]);
void rangoEdad (char input[]);
void cualquierTeclaContinnuar(void);


#endif // VALIDAR_H_INCLUDED
