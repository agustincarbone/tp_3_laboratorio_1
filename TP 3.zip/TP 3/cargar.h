#ifndef CARGAR_H_INCLUDED
#define CARGAR_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <strings.h>
#include "funciones.h"
#include "validar.h"

int getInt(char* mensaje);
float getFloat(char mensaje[]);
char getChar(char mensaje[]);
int getNumeroAleatorio(int desde, int hasta, int iniciar);
void getString(char mensaje[],char arrayChar[]);
void getText(char* mensaje,char* arrayChar,int cantidadDeCaracteres);
int getNumerosChar (char array[],char mensaje[]);
int getStringLetras(char mensaje[],char input[]);
int ingresarSoloLetras (char auxiliar[], char mensajeParaPedirDato[],char mensajeError[]);
int cargarDescripcion(EPelicula** pelicula, int index);
int cargarGenero(EPelicula** pelicula,int index);
int cargarDuracion (EPelicula** pelicula,int index);
int cargarlinkImagen(EPelicula** pelicula,int index);
int cargarPuntaje (EPelicula** pelicula,int index);
int cargarTitulo(EPelicula** pelicula,int index);
void mayToMin(char* string);
void agregarExtension(char* array,char* extension);
void getTexto(char* mensaje,char* arrayChar,char* cantidadDeCaracteres);
void crearPisarArchivoBinario(EPelicula** pelicula, int* peliculasCargadas);
int contarPeliculasFile(char* nFile,int* cantidadPeliculas);
void editMovieInFile(EPelicula** pelicula,int indice);
void hardCodearArray (EPelicula** list);
void reservarEspacio(EPelicula** pelicula,int* capacidadTotalPeliculas);
void agregarPeliculaBinario(EPelicula** pelicula,int* peliculasCargadas);
void cargarBaseDeDatos(EPelicula** pelicula,int*  peliculasCargadas,int *capacidadTotalPeliculas, int* cantidadPunteros);
int agregarDatosPelicula(EPelicula** pelicula,int* peliculasCargadas, int* capacidadTotalPeliculas);
void comprimirArrayMovies(EPelicula** pelicula,int* peliculasCargadas, int opcionPelicula,int* capacidadTotalPeliculas);
void ampliacionMemoria(EPelicula** pelicula,int  peliculasCargadas,int* capacidadTotalPeliculas,int* cantidadPunteros);




#endif // CARGAR_H_INCLUDED
