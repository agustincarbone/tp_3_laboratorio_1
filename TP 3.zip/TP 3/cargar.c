#include "cargar.h"

/**
 * @brief Solicita un n�mero al usuario y devuelve el resultado
 * @param mensaje Es el mensaje a ser mostrado
 * @return El n�mero ingresado por el usuario
 */

int getInt(char* mensaje)
{
    int entero;
    printf("%s",mensaje);
    scanf(" %d",&entero);
    return entero;
}

/**
 * @brief Solicita un n�mero al usuario y devuelve el resultado
 * @param mensaje Es el mensaje a ser mostrado
 * @return El n�mero ingresado por el usuario
 */

float getFloat(char mensaje[])
{
    float flotante;
    printf("%s",mensaje);
    scanf("%f",&flotante);
    return flotante;
}

/**
 * @brief Solicita una variable d tipo char al usuario y devuelve el resultado
 * @param mensaje Es el mensaje a ser mostrado
 * @return El caracter ingresado por el usuario
 */

char getChar(char mensaje[])
{
    char caracter;
    printf("%s",mensaje);
    fflush(stdin); // Win
    // fpurge(stdin); //Linux y OSx
    scanf("%c",&caracter);
    return caracter;
}

/**
 * @brief Genera un numero aleatorio con un rango determinado
 * @param desde El valor minimo
 * @param desde El valor m�ximo
 * @return El numero generado de forma autom�tica
 */

int getNumeroAleatorio(int desde, int hasta, int iniciar)
{
    if(iniciar)
        srand (time(NULL));
    return desde + (rand() % (hasta + 1 - desde)) ;
}

/**
 * @brief Solicita un texto al usuario y lo devuelve
 * @param mensaje Es el mensaje a ser mostrado
 * @param input Array donde se cargar� el texto ingresado
 * @return void
 */

void getString(char mensaje[],char arrayChar[])
{
    fflush(stdin);
    printf("%s",mensaje);
    scanf("%s",arrayChar);
}

/**
 * brief Solicita un texto al usuario y lo devuelve, a diferencia de getString, incluye todo menos el punto '.'
 * @param mensaje Es el mensaje a ser mostrado
 * @param input Array donde se cargar� el texto ingresado
 * @return void
 */

void getText(char* mensaje,char* arrayChar,int cantidadDeCaracteres)
{
    if(cantidadDeCaracteres==21)
    {
        fflush(stdin);
        printf("%s",mensaje);
        scanf("%21[^\n]",arrayChar);
    }
    else if(cantidadDeCaracteres==51)
    {
        fflush(stdin);
        printf("%s",mensaje);
        scanf("%51[^\n]",arrayChar);
    }
    else if(cantidadDeCaracteres==101)
    {
        fflush(stdin);
        printf("%s",mensaje);
        scanf("%101[^\n]",arrayChar);
    }
    else if(cantidadDeCaracteres==201)
    {
        fflush(stdin);
        printf("%s",mensaje);
        scanf("%101[^\n]",arrayChar);
    }

}

/** \brief imprime un texto que indica la informacion a ingresar
 *
 * \param mensaje char* reciibe el mensaje
 * \param arrayChar char* recibe el puntero del arrray
 * \param cantidadDeCaracteres char* recibe la cantidad maxima de caracteres
 * \return void
 *
 */
void getTexto(char* mensaje,char* arrayChar,char* cantidadDeCaracteres)
{
    int i;
    char mascara[10]="%";
    strcpy((mascara+1),cantidadDeCaracteres);
    i=1+strlen(cantidadDeCaracteres);
    strcpy((mascara+i),"[^\n]");
    fflush(stdin);
    printf("%s",mensaje);
    scanf(mascara,arrayChar);
}

/**
 * @brief Solicita un texto num�rico al usuario y lo devuelve
 * @param mensaje Es el mensaje a ser mostrado
 * @param input Array donde se cargar� el texto ingresado
 * @return 1 si el texto contiene solo n�meros
 */

int getNumerosChar (char array[],char mensaje[])
{
    fflush( stdin );
    int retorno=0;
    getString(mensaje,array);
    if(esNumeroChar(array))
    {
        retorno= 1;
    }
    return retorno;
}

/**
* @brief Solicita un texto, conformado solo con letras, al usuario y lo devuelve
* @param mensaje Es el mensaje a ser mostrado
* @param input Array donde se cargar� el texto ingresado
* @return 1 si el texto contiene solo letras
*/

int getStringLetras(char mensaje[],char input[])
{
    fflush( stdin );
    getString(mensaje,input);
    if(esSoloLetras(input))
    {
        return 1;
    }
    return 0;
}

/**
 * @brief Solicita un texto, conformado solo con letras, al usuario, dando la posibilidad de reintentar cuantas veces lo desee el
 * usuario
 * @param str Array con la cadena a ser analizada
 * @param mensajeParaPedirDato mensaje para pedir el dato al usuario
 * @param mensajeError mensaje de error
 * \return 1 si contiene solo ' ' y letras y 0 si no lo es
 */

int ingresarSoloLetras (char auxiliar[], char mensajeParaPedirDato[],char mensajeError[])
{
    char seguir='s';
    int cargaExitosa;
    do
    {
        cargaExitosa=getStringLetras(mensajeParaPedirDato,auxiliar);
        if(!(cargaExitosa))
        {
            printf(mensajeError);// Ejemplo "Ha ingresado caracteres invalidos para un nombre.\n"
            seguir=getChar("Desea reintentar? s/n");
        }
    }
    while(cargaExitosa!=1 && seguir == 's');
    return cargaExitosa;
}

/**
 *  Carga y valida la descripcion para una pelicula
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param index valor de desplazamiento del puntero
 *  @return 1 si se cargo exitosamente y 0 en caso contrario
 */

int cargarDescripcion(EPelicula** pelicula, int index)
{
    char auxiliarDescripcion[100];
    int cantiadadDeCaracteres;
    int retorno=0;
    char seguir='n';

    do
    {
        getText("\nIngrese la descripcion(maximo de 50 caracteres):\n",auxiliarDescripcion,51);
        if((cantiadadDeCaracteres=strlen(auxiliarDescripcion))<51)
        {
            strcpy(((*(pelicula+index))->descripcion),auxiliarDescripcion);
            retorno=1;
        }
        else
        {
            seguir=getChar("Ingreso una descripcion superior a 50  caracteres.\nDesea reintentar? s/n:\n");
        }
    }
    while(seguir=='s' && retorno ==0);
    return retorno;

}

/**
 *  Carga y valida el genero para una pelicula
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param index valor de desplazamiento del puntero
 *  @return 1 si se cargo exitosamente y 0 en caso contrario
 */

int cargarGenero(EPelicula** pelicula,int index)
{
    char auxiliarGenero[52];
    int cantiadadDeCaracteres;
    int retorno=0;
    char seguir='n';
    do
    {
        getText("\nIngrese el genero(maximo de 20 caracteres):\n",auxiliarGenero,51);
        if((cantiadadDeCaracteres=strlen(auxiliarGenero))<51)
        {
            strcpy(((*(pelicula+index))->genero),auxiliarGenero);
            retorno=1;
        }
        else
        {
            seguir=getChar("\nDesea reintentar? s/n:\n");
        }

    }
    while(retorno!=1 && (seguir!= 's' || seguir!= 'S'));

    return retorno;
}

/**
 *  Carga y valida la duracion para una pelicula
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param index valor de desplazamiento del puntero
 *  @return 1 si se cargo exitosamente y 0 en caso contrario
 */

int cargarDuracion (EPelicula** pelicula,int index)
{
    char seguir='s';
    int retorno=0;
    char auxiliar[20];
    do
    {

        retorno=getNumerosChar(auxiliar,"\nIngrese la duracion de la pelicula (minutos):\n");
        if(retorno==0 || (atoi(auxiliar)<40) || (atoi(auxiliar)>5220 ))
        {
            /**Largo minimo para una pelicula, segun la British Film Institute, el largo maximo corresponde a Modern
            *  Times Forever(Stora Enso Building, Helsinki), la pelicula con el record guines de mayor duracion.**/
            printf("\nValor incorrecto.");
            retorno=0;
            seguir=getChar("Desea reintentar? s/n");
        }
        else
        {
            retorno = 1;
            strcpy((*(pelicula+index))->duracion,(auxiliar));
        }
    }
    while(retorno!=1 && seguir == 's');


    return retorno;
}

/**
 *  Carga un link a una imagen para una pelicula
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param index valor de desplazamiento del puntero
 *  @return 1 si se cargo exitosamente y 0 en caso contrario
 */

int cargarlinkImagen(EPelicula** pelicula,int index)
{
    char auxiliarLink[102];
    int cantiadadDeCaracteres;
    int retorno=0;
    char seguir='n';
    do
    {
        getText("\nIngrese el link:\n",auxiliarLink,101);
        if((cantiadadDeCaracteres=strlen(auxiliarLink))<101)
        {

            strcpy(((*(pelicula+index))->linkImagen),auxiliarLink);
            retorno=1;
        }
        else
        {
            seguir=getChar("\nDesea reintentar? s/n:\n");
        }

    }
    while(retorno!=1 && (seguir!= 's' || seguir!= 'S'));

    return retorno;
}

/**
 *  Carga y valida un puntaje a una imagen para una pelicula
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param index valor de desplazamiento del puntero
 *  @return 1 si se cargo exitosamente y 0 en caso contrario
 */

int cargarPuntaje (EPelicula** pelicula,int index)
{
    char seguir='s';
    int retorno=0;
    char auxiliar[20];
    do
    {

        retorno=getNumerosChar(auxiliar,"\nIngrese el puntaje de la pelicula(0-5):\n");
        if(retorno==0 || (atoi(auxiliar)<0) || (atoi(auxiliar)>5 ))
        {
            printf("Valor incorrecto.");
            retorno=0;
            seguir=getChar("Desea reintentar? s/n");
        }
        else
        {
            retorno = 1;
            strcpy((*(pelicula+index))->puntaje,(auxiliar));
        }
    }
    while(retorno!=1 && seguir == 's');


    return retorno;
}

/**
 *  Cuenta la cantidad de estructuras en el archivo y
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param cantidadPeliculas cantidad de peliculas cargadas, la misma se edita por referencia con el resultado del conteo
 */

int cargarTitulo(EPelicula** pelicula,int index)
{
    char auxiliarTitulo[22];
    int cantiadadDeCaracteres;
    int retorno=0;
    char seguir='n';
    do
    {
        getText("\nIngrese el titulo(maximo de 50 caracteres):\n",auxiliarTitulo,51);
        if((cantiadadDeCaracteres=strlen(auxiliarTitulo))<51)
        {
            strcpy(((*(pelicula+index))->titulo),auxiliarTitulo);
            retorno=1;
        }
        else
        {
            seguir=getChar("\nDesea reintentar? s/n:\n");
        }

    }
    while(retorno!=1 && (seguir!= 's' || seguir!= 'S'));

    return retorno;
}

/**
 *  Sobreescribe la una estructura dentro de un archivo
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param indice es el subindice en el array, que en este caso indica el desplazamiento dentro del archivo
 */

void mayToMin(char* string)
{
	int i=0;
	int diferencia='A'-'a';
	for (i=0;string[i]!='\0';++i)
	{
		if(string[i]>='A'&&string[i]<='Z')
		{
			string[i]=string[i]-diferencia;
		}
	}
}

/** \brief crea una extesion al archivo
 *
 * \param array char* recibe el array
 * \param extension char* recibe la extension a usar
 * \return void
 *
 */
void agregarExtension(char* array,char* extension)
{
    int i;
    for(i=0;*(array+i)!='\0'&&*(array+i)!='.';)
    {
        i++;
    }
    strcpy((array+i),extension);
}

/**
 *  Cuenta la cantidad de estructuras en el archivo y
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param cantidadPeliculas cantidad de peliculas cargadas, la misma se edita por referencia con el resultado del conteo
 */

int contarPeliculasFile(char* nFile,int* cantidadPeliculas)
{
    int retorno=0;
    FILE* pFile;
    pFile=fopen(nFile,"rb");
    if(pFile!=NULL)
    {
        fseek(pFile,0,SEEK_END);
        (*cantidadPeliculas)=(ftell(pFile))/(sizeof(EPelicula));
        fclose(pFile);
        retorno=1;
    }
    return retorno;
}

/**
 *  Agrega una variable de tipo EPelicula al final del archivo
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param peliculasCargadas cantidad de peliculas cargadas hasta el momento
 *  @param capacidadTotalPeliculas espacio reservado para guardar peliculas
 *  @param cantidadPunteros cantidad de punteros disponibles
 */

void editMovieInFile(EPelicula** pelicula,int indice)
{
    FILE* pFileBin=NULL;
    pFileBin=fopen("pelicula.txt","r+b");
    if(pFileBin==NULL)
        printf("Error al intentar abrir el archivo.");
    else
    {
        pFileBin=fopen("pelicula.txt","ab");
        if(pFileBin==NULL)
        {
            printf("\nError, no se pudo acceder a la base de datos.");
            getch();
        }
        else
        {

            fseek(pFileBin,sizeof(EPelicula)*indice,SEEK_SET);
            fwrite(((*(pelicula+indice))),sizeof(EPelicula),1,pFileBin);
            fclose(pFileBin);
        }
    }
}

/**
 *  Disminuye el valor de peliculas cargadas en 1 y hace un swap entre el puntero a la pelicula a 'eliminar' y la ultima
 *  a modo de procesar lo menos posible.
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param peliculasCargadas cantidad de peliculas cargadas hasta el momento
 *  @param opcionPelicula es un numero de referencia(indice +1) para encontrar una pel�cula
 *  @param capacidadTotalPeliculas espacio reservado para guardar peliculas
 */

void comprimirArrayMovies(EPelicula** pelicula,int* peliculasCargadas, int opcionPelicula,int* capacidadTotalPeliculas)
{
    int i;
    EPelicula* auxiliarLista;

    auxiliarLista=(*(pelicula+opcionPelicula));
    (*(pelicula+opcionPelicula))=(*(pelicula+(*peliculasCargadas-1)));
    (*(pelicula+(*peliculasCargadas-1)))=auxiliarLista;
    (*peliculasCargadas)--;

    i=((*capacidadTotalPeliculas)-1);
    while(((*capacidadTotalPeliculas)-((*peliculasCargadas)))>10)
    {
        free(*(pelicula+i));
        (*capacidadTotalPeliculas)--;
    }
}

/**
 *  Carga en la memoria una cantidad determinada de peliculas
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 */

void hardCodearArray(EPelicula** list)
{
    int i=0;
    strcpy((*(list+i))->descripcion,"Rogue One, es una pelicula de tipo spin-off con respecto al canon de peliculas de la franquicia Star Wars.");
    strcpy((*(list+i))->titulo,"Rogue One");
    strcpy((*(list+i))->genero,"Ciencia Ficcion");
    strcpy((*(list+i))->linkImagen,"https://i2.wp.com/akihabarablues.com/wp-content/uploads/2016/12/rogue-one-poster.jpg");
    strcpy(((*(list+i))->puntaje),"3");
    strcpy(((*(list+i))->duracion),"140");
    i++;
    strcpy((*(list+i))->descripcion,"Esta pelicula bla bla bla...");
    strcpy((*(list+i))->titulo,"American History X");
    strcpy((*(list+i))->genero,"Drama");
    strcpy((*(list+i))->linkImagen,"https://images-na.ssl-images-amazon.com/images/M/MV5BMjMzNDUwNTIyMF5BMl5BanBnXkFtZTcwNjMwNDg3OA@@._V1_.jpg");
    strcpy(((*(list+i))->puntaje),"5");
    strcpy(((*(list+i))->duracion),"190");
    i++;
    strcpy((*(list+i))->descripcion,"Esta pelicula bla bla bla...");
    strcpy((*(list+i))->titulo,"Pulp Fiction");
    strcpy((*(list+i))->genero,"Policial");
    strcpy((*(list+i))->linkImagen,"http://www.gstatic.com/tv/thumb/peliculaposters/15684/p15684_p_v8_ac.jpg");
    strcpy(((*(list+i))->puntaje),"5");
    strcpy(((*(list+i))->duracion),"140");
    i++;
    strcpy((*(list+i))->descripcion,"La mejor peli del mundo, aunque con algunos errores.");
    strcpy((*(list+i))->titulo,"Interestellar");
    strcpy((*(list+i))->genero,"Ciencia ficcion / Drama");
    strcpy((*(list+i))->linkImagen,"http://ia.media-imdb.com/images/M/MV5BMjIxNTU4MzY4MF5BMl5BanBnXkFtZTgwMzM4ODI3MjE@._V1_SX640_SY720_.jpg");
    strcpy(((*(list+i))->puntaje),"5");
    strcpy(((*(list+i))->duracion),"169");
    i++;
    strcpy((*(list+i))->descripcion,"Descripcion.");
    strcpy((*(list+i))->titulo,"The Godfather");
    strcpy((*(list+i))->genero,"Policial");
    strcpy((*(list+i))->linkImagen,"http://www.youfeelm.com/wp-content/uploads/afiche_elpadrino.jpg");
    strcpy(((*(list+i))->puntaje),"5");
    strcpy(((*(list+i))->duracion),"169");
}

/**
 *  Reserva espacio en memoria para una cantidad estimada de peliculas, si no llega a cumplir el requisito, avisa por pantalla y
 *  edita el valor original por referencia.
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param capacidadTotalPeliculas espacio reservado para guardar peliculas
 */

void reservarEspacio(EPelicula** pelicula,int* capacidadTotalPeliculas)
{
    int i;
    for(i=0; i<*capacidadTotalPeliculas; i++)
    {
        (*(pelicula+i))=(EPelicula*)malloc(sizeof(EPelicula));
        if((*(pelicula+i))==NULL)
        {
            printf("\nPoca memoria en disco.");
            *capacidadTotalPeliculas=i;
            break;
        }
    }
}

/**
 *  Si es que existe un archivo pelicula.txt con datos, este los carga en el array y edita la cantidad de peliculas cargadas
 *  por referencia.
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param peliculasCargadas cantidad de peliculas cargadas hasta el momento
 *  @param capacidadTotalPeliculas espacio reservado para guardar peliculas
 *  @param cantidadPunteros cantidad de punteros disponibles
 */

void cargarBaseDeDatos(EPelicula** pelicula,int*  peliculasCargadas,int *capacidadTotalPeliculas, int* cantidadPunteros)
{
    if(contarPeliculasFile("pelicula.txt",peliculasCargadas))
    {
        ampliacionMemoria(pelicula,(*peliculasCargadas),capacidadTotalPeliculas,cantidadPunteros);
        int i;
        FILE* pFileBin=NULL;
        EPelicula* auxiliarMovie;
        int cantMovies=0;
        pFileBin=fopen("pelicula.txt","rb");
        if(pFileBin==NULL)
             return;
        else
        {
            if((*peliculasCargadas)<100)
            auxiliarMovie=(EPelicula*)malloc(sizeof(EPelicula)*(cantMovies+100));
            else
            auxiliarMovie=(EPelicula*)malloc(sizeof(EPelicula)*((*peliculasCargadas)+100));
            cantMovies+=fread(auxiliarMovie, sizeof(EPelicula),(*peliculasCargadas), pFileBin);
        }
        fclose(pFileBin);
        *peliculasCargadas=cantMovies;
        ampliacionMemoria(pelicula, *peliculasCargadas,capacidadTotalPeliculas,cantidadPunteros);
        for(i=0; i<*peliculasCargadas; i++)
            ((**(pelicula+i)))=(*(auxiliarMovie+i));

    }
}

void crearPisarArchivoBinario(EPelicula** pelicula, int* peliculasCargadas)
{
    int i;

        FILE* pFileBin=NULL;
        pFileBin=fopen("pelicula.txt","wb");
        for(i=0; i<*peliculasCargadas; i++)
        {
            fwrite(*(pelicula+i),sizeof(EPelicula),1,pFileBin);
        }
        fclose(pFileBin);
        pFileBin=fopen("pelicula.txt","wb");
        for(i=0; i<*peliculasCargadas; i++)
        {
            fwrite(*(pelicula+i),sizeof(EPelicula),1,pFileBin);
        }
        fclose(pFileBin);
}

/**
 *  Agrega una variable de tipo EPelicula al final del archivo
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param peliculasCargadas cantidad de peliculas cargadas hasta el momento
 *  @param capacidadTotalPeliculas espacio reservado para guardar peliculas
 *  @param cantidadPunteros cantidad de punteros disponibles
 */

void agregarPeliculaBinario(EPelicula** pelicula,int* peliculasCargadas)
{
    FILE* pFileBin=NULL;
    pFileBin=fopen("pelicula.txt","rb");
    if(pFileBin==NULL)
        crearPisarArchivoBinario(pelicula,peliculasCargadas);
    else
    {
        pFileBin=fopen("pelicula.txt","ab");
        if(pFileBin==NULL)
            printf("\nError, no se pudo acceder a la base de datos.");
        else
        {
            fwrite(*(pelicula+*peliculasCargadas),sizeof(EPelicula),1,pFileBin);
            getch();
            fclose(pFileBin);
        }
    }
}

/**
 *  Agrega una pelicula al archivo binario
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param peliculasCargadas cantidad de peliculas cargadas hasta el momento
 *  @param capacidadTotalPeliculas espacio reservado para guardar peliculas
 */

int agregarDatosPelicula(EPelicula** pelicula,int* peliculasCargadas, int* capacidadTotalPeliculas)
{
    int retorno;
    retorno=cargarTitulo(pelicula,*peliculasCargadas);
    if(retorno)
        retorno=cargarDuracion(pelicula,*peliculasCargadas);
    if(retorno)
        retorno=cargarGenero(pelicula,*peliculasCargadas);
    if(retorno)
        retorno=cargarlinkImagen(pelicula,*peliculasCargadas);
    if(retorno)
        retorno=cargarPuntaje(pelicula,*peliculasCargadas);
    if(retorno)
        retorno=cargarDescripcion(pelicula,*peliculasCargadas);
    return retorno;
}

/**
 *  Amplia el espacio reservado para agregar peliculas
 *  @param pelicula puntero a punteros de estructura EPelicula a ser agregada al archivo
 *  @param peliculasCargadas cantidad de peliculas cargadas hasta el momento
 *  @param capacidadTotalPeliculas espacio reservado para guardar peliculas
 *  @param cantidadPunteros cantidad de punteros disponibles
 */

void ampliacionMemoria(EPelicula** pelicula,int peliculasCargadas,int* capacidadTotalPeliculas,int* cantidadPunteros)
{
    EPelicula** auxiliarArray;
    int index;
    while(((*capacidadTotalPeliculas)-peliculasCargadas)<10)
    {
        auxiliarArray=(EPelicula**)realloc(pelicula,sizeof(EPelicula*)*((*cantidadPunteros)+100));
        if(auxiliarArray==NULL)
        {
            printf("SIN MEMORIA.");
            return;
        }
        pelicula=auxiliarArray;
        *cantidadPunteros+=100;
        printf("\nAmpliacion de memoria exitosa!!\n\n");

        for(index=*capacidadTotalPeliculas; index<(*capacidadTotalPeliculas+100); index++)
        {
            *(pelicula+index)=(EPelicula*)malloc(sizeof(EPelicula));
            if(*(pelicula+index)==NULL)
            {
                break;
                printf("SIN MEMORIA");
                auxiliarArray=(EPelicula**)realloc(pelicula,sizeof(EPelicula*)*(*cantidadPunteros-(100+index)));
                if(auxiliarArray!=NULL)
                    pelicula=auxiliarArray;
            }
        }
        if(index==(*capacidadTotalPeliculas+(100)))
        {
            printf("Ampliacion exitosa.");
            *capacidadTotalPeliculas=*capacidadTotalPeliculas+100;
        }
    }
    while(((*capacidadTotalPeliculas)-peliculasCargadas)>120)
    {
        auxiliarArray=(EPelicula**)realloc(pelicula,sizeof(EPelicula*)*((*cantidadPunteros)-50));
        if(auxiliarArray==NULL)
        {
            printf("SIN MEMORIA.");
            return;
        }
        pelicula=auxiliarArray;
        *cantidadPunteros-=50;
        printf("\nAmpliacion de memoria exitosa!!\n\n");

        for(index=*capacidadTotalPeliculas; index>(*capacidadTotalPeliculas-50); index--)
        {
            free(*(pelicula+index));
        }
            printf("Se livero espacio en memoria.");
            *capacidadTotalPeliculas=*capacidadTotalPeliculas-50;
    }
}
