#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

typedef struct{
    char titulo[100];
    char genero[100];
    char duracion[5];
    char descripcion[600];
    char puntaje[4];
    char linkImagen[250];
}EPelicula;

void agregarPelicula(EPelicula** pelicula,int*  peliculasCargadas,int* capacidadTotalPeliculas,int* cantidadPunteros);
void borrarPelicula(EPelicula** pelicula, int* peliculasCargadas,int* capacidadTotalPeliculasint,int* cantidadPunteros);
void modificarDatosPelicula(EPelicula** pelicula, int* peliculasCargadas,int* capacidadTotalPeliculas);
void imprimirArchivo(EPelicula** pelicula,int peliculasCargadas);

#endif // FUNCIONES_H_INCLUDED
